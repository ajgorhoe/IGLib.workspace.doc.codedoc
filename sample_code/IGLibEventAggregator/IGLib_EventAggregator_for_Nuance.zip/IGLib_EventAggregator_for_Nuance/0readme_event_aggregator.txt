
Generic event aggregator; Investigative Generic Library's experimental
project.
Copyright Igor Grešovnik. No licence offered (software not distributed).

Code was made available for use in Nuance Communication's software.
Commits that were made available for use in Nuance: 
  
Repo iglib.misc.eventaggregator.git:
  28. 2. 2021:
  Commit: 3b483c689198cdbd3fc14d49f8d3ebc9500e5dfe
  Branch: master

