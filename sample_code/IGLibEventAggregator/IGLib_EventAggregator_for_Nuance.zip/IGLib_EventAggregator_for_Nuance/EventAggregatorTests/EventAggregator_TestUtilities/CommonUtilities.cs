﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IG.Tests.Events
{

    // Copyright (c) Igor Grešovnik (2008 - present); Investigative Generic Library's experimentation project.


    /// <summary>Classes that contain unique application-level ID. This helps identify objects passed around in tests.</summary>
    public interface IGloballyIdentifiable
    {
        int ObjectId { get; }
    }


    /// <summary>Base class for classes whose objects have a unique application-wide ID.</summary>
    public abstract class GloballyIdentifiableTestUtil
    {
        private static int _nextId = 0;
        private static object _lock = new object();
        protected static int NextGlobalId {
            get
            {
                lock (_lock)
                {
                    return (++_nextId);
                }
            }
        }

        /// <summary>Application-wide unique object ID (unique across objects of all derived types).</summary>
        public int ObjectId { get; } = NextGlobalId;

        /// <summary>Used for locking internal resources by classes that need certain thread safety properties.</summary>
        protected object Lock { get; } = new object();

        /// <summary>Whether or not actions performed are printeed to console.</summary>
        public virtual bool ConsoleOutput { get; set; } = true;

        public override string ToString()
        {
            return $"{{{GetType()}: OID = {ObjectId}}}";
        }
    }

    public class TestEventInfo: GloballyIdentifiableTestUtil, IGloballyIdentifiable
    {

        public TestEventInfo(object sender, object eventArgs)
        {
            SenderObject = sender;
            EventArgsObject = eventArgs; 
        }

        public object SenderObject { get; protected set; }

        public object EventArgsObject { get; protected set; }

        public ITestPublisher SenderTestable {
            get {
                return SenderObject == null? null: SenderObject as ITestPublisher;
            }
        }

        public ITestEventData EventArgsTestable {
            get
            {
                return EventArgsObject == null? null: EventArgsObject as ITestEventData;
            } 
        }

        /// <summary>Returns <see cref="IGloballyIdentifiable.ObjectId"/> of the event's data, 
        /// or -1 if event's data does not exist.</summary>
        public int DataId { get { return EventArgsTestable == null ? -1 : EventArgsTestable.ObjectId;  } }

    }






}
