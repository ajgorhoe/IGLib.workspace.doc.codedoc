using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("IGLib - EventAggregator Tests")]
[assembly: AssemblyDescription("Investigative Generic Library - Tests, Utilities for event driven applications.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Igor Grešovnik")]
[assembly: AssemblyProduct("IGLib_EventAggregator_Tests")]
[assembly: AssemblyCopyright("Copyright © Igor Grešovnik (2008 - present).")]
[assembly: AssemblyTrademark("IGLib")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("4371fb15-bbd1-4a2e-9d7f-dd3779f6adea")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.7.2")]
//[assembly: AssemblyFileVersion("1.0.0.0")]
